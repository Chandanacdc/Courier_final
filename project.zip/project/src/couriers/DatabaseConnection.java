package couriers;
import java.sql.*;
public class DatabaseConnection {
	protected static Connection intializeDatabase()
			throws SQLException, ClassNotFoundException
			
			{
			
			String dbDriver="com.mysql.jdbc.Driver";
			
				String dbURL ="jdbc:mysql://localhost/couriers";
				String dbUsername ="root";
				String dbPassword ="system";
				
				Class.forName (dbDriver);
				System.out.println("---->BeforeDBConnection<=---");
				
				Connection con =DriverManager.getConnection(dbURL,
						dbUsername,dbPassword);
				
				System.out.println("----->afterDBConnection<=----");
				return con;
			}
			
		}
			

