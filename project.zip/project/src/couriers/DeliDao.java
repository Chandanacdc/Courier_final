package couriers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DeliDao {
	public static int save(Deliver e){  
        int status=0;  
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement(  
                         "insert into deliver(name,password,email,gender,location) values (?,?,?,?,?)");  
            ps.setString(1,e.getName());  
            ps.setString(2,e.getPassword());  
            ps.setString(3,e.getEmail());  
            ps.setString(4,e.getGender());
            ps.setString(5,e.getLocation());
            
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int update(Deliver e){  
        int status=0;  
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement(  
                         "update deliver set name=?,password=?,email=?,gender=?,location=? where id=?");  
            ps.setString(1,e.getName());  
            ps.setString(2,e.getPassword());  
            ps.setString(3,e.getEmail());  
            ps.setString(4,e.getGender());  
            ps.setString(5,e.getLocation());  
            ps.setInt(6,e.getId());  
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int delete(int id){  
        int status=0;  
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement("delete from deliver where id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return status;  
    }  
    public static Deliver getEmployeeById(int id){  
        Deliver e=new Deliver();  
          
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement("select * from deliver where id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                e.setId(rs.getInt(1));  
                e.setName(rs.getString(2));  
                e.setPassword(rs.getString(3));  
                e.setEmail(rs.getString(4));  
                e.setGender(rs.getString(5));
                e.setLocation(rs.getString(6));  
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return e;  
    }  
    public static List<Deliver> getAllEmployees(){  
        List<Deliver> list=new ArrayList<Deliver>();  
          
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement("select * from deliver");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                Deliver e=new Deliver();  
                e.setId(rs.getInt(1));  
                e.setName(rs.getString(2));  
                e.setPassword(rs.getString(3));  
                e.setEmail(rs.getString(4));  
                e.setGender(rs.getString(5)); 
                e.setLocation(rs.getString(6)); 
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
}



