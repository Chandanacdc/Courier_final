
package couriers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeliServlet")
public class DeliServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		
		Deliver e=DeliDao.getEmployeeById(id);
		//out.print("<style>{"
				//+ "input[type=text]:focus, input[type=password]:focus {" + 
				//"  background-color: #ddd;" + 
				//"  outline: none;" + 
				//"}");
		
		RequestDispatcher rd=request.getRequestDispatcher("navbar.html");
        rd.include(request, response);
		//out.print("</style>");
		out.print("<form  style='background-color:#ffff99;'action='DeliServlet2' method='post'>");
		
		out.print("<center>");
		out.println("<h1>Update Delivery Person</h1>");
		 out.print("<table  width='50%'"); 
		out.print("<tr><td></td><td><input type='hidden' name='id' value='"+e.getId()+"'/></td></tr>");
		out.print("<tr><td><b>UserName:</td><td><input type='text' name='name'  style:height='200px;' size='100' value='"+e.getName()+"'/></td></tr><br><br>");
		
		out.print("<tr><td><b>Email:</td><td><input type='email' name='email' size='100' value='"+e.getEmail()+"'/></td></tr>");
	
		out.print("<tr><td><b>Location:</td><td><input  type='text' name='location' size='100' value='"+e.getLocation()+"'/></td></tr>");
	
		out.print("</select>");
		out.print("</td></tr>");
		
		out.print("<tr><td colspan='2'><button type='submit'style='background-color:#99e6ff;'  size= '20'value='Save'>Save</td></tr></button>");
		

		out.print("</table>");
		
		out.print("</form>");
		out.print("</center>");
		out.close();
	}

	private void print(String string) {
		// TODO Auto-generated method stub
		
	}
}


