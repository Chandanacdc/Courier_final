package couriers;

import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/ViewDeliver")  
public class ViewDeliver extends HttpServlet {  
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
               throws ServletException, IOException { 
    	
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();
       // out.print("<center><img src='images/delperson.jpg' alt='image' /></center>");
        RequestDispatcher rd=request.getRequestDispatcher("navbar.html");
        rd.include(request, response);
        out.print("<form  style='background-color:#ffff99;'action='DeliServlet2' method='post'>");
        out.println("<a style='padding-left:200px;' href='adddelivery.html'>Add New Employee</a>");  
        
        out.println("<center><h1>Delivery Person list</h1></center>");  
        out.println("<body style='background-color:#CD853F;'>");  
        List<Deliver> list=DeliDao.getAllEmployees();  
         
        out.print("<center><table border='1' width='80%'</center>");  
        
        out.print("<tr><th>Id</th><th>Name</th><th>Email</th><th>Location</th><th>Edit</th><th>Delete</th></tr>");  
        for(Deliver e:list){  
         out.print("<tr><td>"+e.getId()+"</td><td>"+e.getName()+"</td><td>"+e.getEmail()+"</td><td>"+e.getLocation()+"</td><td><a href='DeliServlet?id="+e.getId()+"'>edit</a></td>  <td><a href='DeleteDeliver?id="+e.getId()+"'>delete</a></td></tr>");  
        }  
        out.print("</table>");  
         

          
        out.close();  
    }  
}  
